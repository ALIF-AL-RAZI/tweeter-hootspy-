/* eslint-disable prettier/prettier */
/* eslint-disable no-unused-vars */
import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';
import TweetsyConfig from 'TweetsyConfig';

export const apiSlice = createApi({
    // eslint-disable-next-line prettier/prettier
    reducerPath: 'apir',
    baseQuery: fetchBaseQuery({
        baseUrl: 'https://jsonplaceholder.typicode.com/',
        // baseUrl: TweetsyConfig.getNodeUrl(),

        prepareHeaders: (headers, { getState }) => {
            headers.append('Authorization', `Bearer `);
            return headers;
        }
    }),
    // tags: ['users', 'user', 'courses'],
    endpoints: (builder) => ({
        getPlans: builder.query({
            query: (accessToken) => `posts`
        })
    })
});
export const { usegetPlansQuery } = apiSlice;
