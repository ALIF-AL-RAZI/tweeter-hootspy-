// third-party
import { configureStore } from '@reduxjs/toolkit';
import { useDispatch as useAppDispatch, useSelector as useAppSelector } from 'react-redux';

import { persistStore } from 'redux-persist';

// project imports
import rootReducer from './reducer';
import { apiSlice } from './apiSlice';

// ==============================|| REDUX - MAIN STORE ||============================== //
const store = configureStore({
    reducer: rootReducer,
    [apiSlice.reducerPath]: apiSlice.reducer,
    middleware: (getDefaultMiddleware) =>
        getDefaultMiddleware({ serializableCheck: false, immutableCheck: false }).concat(apiSlice.middleware)
    // middleware: (getDefaultMiddleware) => getDefaultMiddleware().concat(apiSlice.middleware)
});

const persister = persistStore(store);

const { dispatch } = store;

const useDispatch = () => useAppDispatch();
const useSelector = useAppSelector;

export { store, persister, dispatch, useSelector, useDispatch };
